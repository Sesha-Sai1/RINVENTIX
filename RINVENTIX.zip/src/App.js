import "./App.css";
import MainChatReference from "./components/MainChatReference";
import MainChatScreen from "./components/MainChatScreen";
import Sidebar from "./components/Sidebar";

function App() {
  return (
    <div className="App">
      <MainChatReference />
    </div>
  );
}

export default App;
